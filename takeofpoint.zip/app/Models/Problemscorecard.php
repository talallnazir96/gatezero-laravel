<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Problemscorecard extends Model {
	protected $table = 'motivation_parity';
	protected $primaryKey = 'motivational_id';
}