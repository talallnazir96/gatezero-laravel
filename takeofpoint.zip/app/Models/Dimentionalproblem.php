<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Dimentionalproblem extends Model {
	protected $table = 'dimentional_problem';
	protected $primaryKey = 'dimentional_id';
}