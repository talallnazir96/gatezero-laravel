<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Whoiscas extends Model {
	protected $table = 'whoiscas';
	protected $primaryKey = 'cas_id';
}