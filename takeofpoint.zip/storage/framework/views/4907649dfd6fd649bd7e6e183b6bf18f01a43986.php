<pre>
<?php echo e(print_r($mydata)); ?>

<?php
// foreach($mydata as $data){
//     print_r($data);
// }

?><?php /**PATH E:\PHP\blog\resources\views/testview.blade.php ENDPATH**/ ?>