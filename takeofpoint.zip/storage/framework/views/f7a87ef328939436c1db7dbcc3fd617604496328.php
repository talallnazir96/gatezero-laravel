<h4>You are receiving this email because we received a email reset request for your account.</h4>
<b>Name: </b><?php echo e($name); ?> </br>
<b>Your Password : </b><?php echo e($password); ?> </br><?php /**PATH C:\Users\Dreams\takeofpoint\resources\views/forgot.blade.php ENDPATH**/ ?>