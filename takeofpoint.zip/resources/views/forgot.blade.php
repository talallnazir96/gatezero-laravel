<h4>You are receiving this email because we received a email reset request for your account.</h4>
<b>Name: </b>{{ $name }} </br>
<b>Your Password : </b>{{ $password }} </br>